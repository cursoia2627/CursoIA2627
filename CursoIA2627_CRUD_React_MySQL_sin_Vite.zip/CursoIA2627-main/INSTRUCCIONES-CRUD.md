# CRUD real de Clientes y Consultas (React sin Vite + Express + MySQL)

Este proyecto **ya tenía un backend con rutas REST**. Esta actualización conecta la pestaña **Clientes** a esas rutas y añade una subpestaña **Consultas**. La información se guarda en MySQL, no en `localStorage`.

## Requisitos

- Node.js 20 o superior
- MySQL local o Aiven accesible
- Las credenciales correctas de la base de datos

## 1. Preparar el backend (VS Code, terminal 1)

```powershell
cd backend
copy .env.example .env
npm install
npm run dev
```

Editar `backend/.env` con tus credenciales REALES de MySQL. **No se incluyen las credenciales del ZIP original por seguridad.** Para MySQL local normalmente usa `DB_HOST=localhost`, `DB_PORT=3306`, `DB_SSL=false`, usuario, contraseña y base apropiados. Para Aiven, sigue las instrucciones de `backend/README.md`.

Verifica `http://localhost:4000/api/health` y la documentación REST `http://localhost:4000/api/docs`.

Al arrancar el servidor se crean, si no existen, las tablas `clientes` y `atencion_cliente`. **No borra las tablas existentes al arrancar.**

## 2. Preparar React (VS Code, terminal 2)

```powershell
cd frontend
copy .env.example .env
npm install
npm start
```

En `frontend/.env` deja `REACT_APP_API_URL=http://localhost:4000/api`. React estará en `http://localhost:3000` (Create React App, **sin Vite**). Si cambias `.env`, reinicia `npm start`.

## 3. Cómo usar el CRUD

En **Clientes**: pulsa **Nuevo Cliente**, rellena el formulario y guarda. Puedes **buscar**, **editar** o **eliminar**. En **Consultas**: crea una consulta para un cliente existente, edita texto/respuesta/estado o elimínala. Todas las acciones se realizan sobre MySQL y actualizan la tabla al terminar.

**Cuidado:** eliminar un cliente elimina también sus consultas asociadas por la clave foránea `ON DELETE CASCADE`.

## Endpoints disponibles

| Método | Ruta | Acción |
|---|---|---|
| GET | /api/clientes | Listar |
| GET | /api/clientes/:id | Leer |
| POST | /api/clientes | Crear |
| PUT | /api/clientes/:id | Actualizar |
| DELETE | /api/clientes/:id | Eliminar |
| GET | /api/consultas | Listar |
| GET | /api/consultas/:id | Leer |
| POST | /api/consultas | Crear |
| PATCH | /api/consultas/:id | Actualizar |
| DELETE | /api/consultas/:id | Eliminar |

## Archivos principales modificados

- `frontend/src/api/client.js`: funciones HTTP para el CRUD.
- `frontend/src/components/Clientes.js`: conexión de formularios, búsqueda, subpestañas y tablas.
- `frontend/src/App.js`: elimina el estado local de clientes; sigue conservando la demostración del chat.
- `frontend/src/styles.css`: estilos adicionales del CRUD.

## Consideraciones importantes

- El chat conserva sus conversaciones **de demostración en localStorage**; esta actualización no convierte el chatbot en IA funcional. Avatar conserva su propia conexión existente al backend y su integración externa, cuya operación depende de la configuración del proyecto original.
- Las pantallas cargan un máximo de 1000 registros por recurso; para producción conviene implementar paginación en el servidor y búsqueda con filtros API.
- El backend no tiene autenticación ni autorización: **no lo publiques abierto en internet** sin añadirlas.
- `.env`, `node_modules` y archivos de compilación se excluyen del ZIP y Git para evitar credenciales expuestas, peso excesivo y errores de rutas largas en Windows.
